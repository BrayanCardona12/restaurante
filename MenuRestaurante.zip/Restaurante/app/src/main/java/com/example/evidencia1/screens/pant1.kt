package com.example.evidencia1.screens

import androidx.compose.foundation.Image
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.material.Icon
import androidx.compose.material.Scaffold
import androidx.compose.material.Text
import androidx.compose.material.TopAppBar
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AddCircle
import androidx.compose.material.icons.filled.ArrowForward
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.example.evidencia1.R
import com.example.evidencia1.models.InfoUsers
import com.example.evidencia1.nav.NavRoute

@Composable
fun PantallaMain1(navController: NavController) {
    Scaffold(
        topBar = {
            TopAppBar() {
                Icon(imageVector = Icons.Default.ArrowForward, contentDescription = ".",
                    modifier = Modifier
                        .clickable { navController.navigate(route = NavRoute.PantallaMain2.route) }
                )
            }
        }
    ) {
        ContMain1(navController)
    }

}


@Composable
fun ContMain1(navController: NavController) {
    var user1 = InfoUsers("Carlos", "Hernandez", 1234567, R.drawable.user11)
Column() {
    Image(painter = painterResource(id = user1.ima), contentDescription = "", modifier = Modifier.size(500.dp))
    Text(text = "Nombre: ${user1.nom}")
    Text(text = "Apellido ${user1.ape}" )
    Text(text = "Cedula: ${user1.cc}")
}

}

