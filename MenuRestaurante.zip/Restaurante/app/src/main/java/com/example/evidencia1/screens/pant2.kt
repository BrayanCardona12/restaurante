package com.example.evidencia1.screens

import androidx.compose.foundation.Image
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.ArrowForward
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.navigation.NavController
import com.example.evidencia1.models.InfoFood
import com.example.evidencia1.models.datoss
import com.example.evidencia1.nav.NavRoute

@Composable
fun PantallaMain2(navController: NavController) {
    Scaffold(
        topBar = {
            TopAppBar() {
                Icon(imageVector = Icons.Default.ArrowBack, contentDescription = ".",
                    modifier = Modifier
                        .clickable { navController.navigate(route = NavRoute.PantallaMain1.route) }
                )

            }
        }
    ) {
        LazyColumn() {
            item {
                ContMain2(navController)
            }
        }

    }

}

@Composable
fun Comp1(ima:Int,nom:String,ca:String) {
    Text(text = "Aaa")
}

//@Composable
//fun Comp2(datos: List<InfoFood>) {
//    for (z in datos) {
//        Text(text = "${z}")
//
//    }

@Composable
fun ContMain2(navController: NavController) {

        Column() {
            var datos = datoss
            var estado by remember { mutableStateOf(false) }
            for (z in datos) {
                    Row(modifier = Modifier.clickable { estado = !estado }) {
                        Image(painter = painterResource(id = z.ima), contentDescription = "D", modifier = Modifier
                            .width(150.dp)
                            .height(100.dp))
                            Column() {
                                Text(text = "${z.nom}")
                                Text(text = "Caracteristicas", fontWeight = FontWeight.Bold)
                                Text(text = "${z.caract}" , maxLines = if(estado) Int.MAX_VALUE else 3)
                            }
                    }

            
            }
            Button(onClick = { navController.navigate(NavRoute.PantallaMain3.route) }) {
                Text(text = "Comprar")
            }
        }

    }



