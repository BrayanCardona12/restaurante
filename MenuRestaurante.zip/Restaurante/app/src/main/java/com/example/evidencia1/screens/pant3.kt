package com.example.evidencia1.screens

import androidx.compose.foundation.Image
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.material.Icon
import androidx.compose.material.Scaffold
import androidx.compose.material.Text
import androidx.compose.material.TopAppBar
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.ArrowForward
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.tooling.preview.Preview
import androidx.navigation.NavController
import com.example.evidencia1.R
import com.example.evidencia1.models.InfoUsers
import com.example.evidencia1.nav.NavRoute

@Composable
fun PantallaMain3(navController: NavController) {
    Scaffold(
        topBar = {
            TopAppBar() {
                Icon(imageVector = Icons.Default.ArrowBack, contentDescription = ".",
                    modifier = Modifier
                        .clickable { navController.navigate(route = NavRoute.PantallaMain2.route) }
                )
            }
        }
    ) {
        ContMain3(navController)
    }

}


@Composable
fun ContMain3(navController: NavController) {
    var user1 = InfoUsers("Carlos", "Hernandez", 1234567, R.drawable.user11)
    Row() {
        Image(painter = painterResource(id = user1.ima), contentDescription = "")
        Column {
            Text(text = "Nombree ${user1.nom}")
            Text(text = "Apellido ${user1.ape}")
            Text(text = "CC: ${user1.cc}")
        }
    }

}