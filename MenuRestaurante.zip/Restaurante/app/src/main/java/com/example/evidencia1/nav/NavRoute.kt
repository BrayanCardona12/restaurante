package com.example.evidencia1.nav


sealed class NavRoute(val route:String) {
    object PantallaMain1: NavRoute(route = "pantallaMain1")
    object PantallaMain2: NavRoute(route = "pantallaMain2")
    object PantallaMain3: NavRoute(route = "pantallaMain3")
}
