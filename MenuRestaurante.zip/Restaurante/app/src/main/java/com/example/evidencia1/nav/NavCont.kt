package com.example.evidencia1.nav

import androidx.compose.runtime.Composable
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.example.evidencia1.screens.*

@Composable
fun Navegacion() {
    var navContrl = rememberNavController()
    NavHost(navController = navContrl,
        startDestination = NavRoute.PantallaMain1.route) {
        composable(route = NavRoute.PantallaMain1.route) { PantallaMain1(navContrl) }
        composable(route = NavRoute.PantallaMain2.route) { PantallaMain2(navContrl) }
        composable(route = NavRoute.PantallaMain3.route) { PantallaMain3(navContrl)}
    }

}