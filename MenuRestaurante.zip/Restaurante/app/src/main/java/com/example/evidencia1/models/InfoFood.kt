package com.example.evidencia1.models

data class InfoFood(
    var ima:Int,
    var nom:String,
    var caract:String


    )
