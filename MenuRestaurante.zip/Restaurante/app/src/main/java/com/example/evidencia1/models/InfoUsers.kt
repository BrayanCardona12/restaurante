package com.example.evidencia1.models

open class InfoUsers(var nom:String, var ape:String, var cc:Int, var ima:Int) {

}